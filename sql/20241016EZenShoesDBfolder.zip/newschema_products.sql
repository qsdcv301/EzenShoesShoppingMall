-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: newschema
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `description` text,
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `category_id` int NOT NULL,
  `subcategory_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category_id_idx` (`category_id`),
  KEY `fk_subcategory_id_idx` (`subcategory_id`),
  CONSTRAINT `fk_category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_subcategory_id` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'adistar01',159000,'Adidas Adistar White-Yellow','2024-10-11 08:27:05',2,1),(2,'amplimove01',79000,'Adidas Amplimove White','2024-10-11 08:27:05',2,2),(3,'dropset01',400000,'Adidas Dropset Pink-Black','2024-10-11 08:27:05',2,3),(4,'everyset01',119000,'Adidas Everyset Ivory-Pink','2024-10-11 08:27:05',2,4),(5,'newyork01',129000,'Adidas NewYork Gray-Black','2024-10-11 08:27:05',2,1),(6,'runner01',109000,'Adidas Runner Black-White','2024-10-11 08:27:05',2,2),(7,'running01',69000,'Adidas Running Blue','2024-10-11 08:27:05',2,3),(8,'samba01',139000,'Adidas Samba Black','2024-10-11 08:27:05',2,4),(9,'classic01',69000,'Nike Classic Black','2024-10-11 08:27:08',1,1),(10,'cortez01',129000,'Nike Cortez Brown','2024-10-11 08:27:08',1,2),(11,'dunk01',139000,'Nike Dunk White-Black','2024-10-11 08:27:08',1,3),(12,'picnic01',129000,'Nike Picnic White','2024-10-11 08:27:08',1,4),(13,'uptempo01',209000,'Nike Uptempo Black','2024-10-11 08:27:08',1,1),(14,'v2k01',139000,'Nike V2K Black','2024-10-11 08:27:08',1,2),(15,'vision01',89000,'Nike Vision White','2024-10-11 08:27:08',1,3),(16,'authentic01',105000,'Vans Authentic Gray','2024-10-11 08:27:11',3,4),(17,'checker01',69000,'Vans Checker Orange','2024-10-11 08:27:11',3,1),(18,'skool01',85000,'Vans Skool Gray','2024-10-11 08:27:11',3,2),(19,'upland01',119000,'Vans Upland White','2024-10-11 08:27:11',3,3),(20,'adistar02',159000,'Adidas Adistar White','2024-10-15 07:22:57',2,4),(21,'running02',69000,'Adidas Running White-Black','2024-10-15 07:22:57',2,1),(22,'runner02',109000,'Adidas Runner Black','2024-10-15 07:22:57',2,2),(23,'classic02',69000,'Nike Classic White','2024-10-11 08:27:08',1,3),(24,'classic03',69000,'Nike Classic Black-Brown','2024-10-11 08:27:08',1,4),(25,'cortez02',129000,'Nike Cortez Green','2024-10-11 08:27:08',1,1),(26,'dunk02',139000,'Nike Dunk White','2024-10-11 08:27:08',1,2),(27,'dunk03',139000,'Nike Dunk Ivory-White','2024-10-11 08:27:08',1,3),(29,'uptempo02',209000,'Nike Uptempo White','2024-10-11 08:27:08',1,4),(30,'v2k02',139000,'Nike V2K Obsidian','2024-10-11 08:27:08',1,1),(31,'v2k03',139000,'Nike V2K Silver','2024-10-11 08:27:08',1,2),(32,'v2k04',139000,'Nike V2K Vintagegreen','2024-10-11 08:27:08',1,3),(33,'v2k05',139000,'Nike V2K Wolfgray','2024-10-11 08:27:08',1,4),(34,'adistar02',159000,'Adidas Adistar White','2024-10-15 07:22:57',2,1),(35,'runner02',109000,'Adidas Runner Black','2024-10-15 07:22:57',2,2),(36,'authentic02',105000,'Vans Authentic White','2024-10-15 07:22:57',3,3),(37,'authentic03',105000,'Vans Authentic Black','2024-10-15 07:22:57',3,4),(38,'skool02',85000,'Vans Skool Purple','2024-10-15 07:22:57',3,1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-16 17:20:03
